now=$(date +"%Y-%m-%d %T")
echo "$now "

#now=$(date +"%Y-%m-%d %T")

#echo $( date +%s )

start=$( date --date='1minutes ago' +"%Y-%m-%d %T")


sh /home/sriniv/Downloads/S2C/Sync_SF_Couh/Sync_SF_Couh_run.sh --context_param start="$start" --context_param stop="$now"

