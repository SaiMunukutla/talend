

end=$(($(date +%s%N)/1000000))
echo "$end";

#end=$( date --date='2minutes ago' +"%m/%d/%Y %T")
#echo "$end"

start=$(($(date --date='5minutes ago'  +%s%N)/1000000))
echo "$start";

sh /home/joseph/Downloads/TestCouch/TestCouch/TestCouch_run.sh --context_param view="function(doc,meta){if(doc.deviceid !=null){if(  doc.date > $start)emit(meta.id,doc);}}"

                                                                   
