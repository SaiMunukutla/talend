now=$(date +"%m/%d/%Y %T ");

echo "$now";

start=$( date --date='2minutes ago' +"%m/%d/%Y %T")
echo "$start"

sh /home/sriniv/Downloads/C2S/Sync_Couch_SF/Sync_Couch_SF_run.sh --context_param view="function(doc,meta){if(doc.sensorReading !=null){var docDate= Date.parse(doc.date);var start= Date.parse('$start');var stop = Date.parse('$now');if(docDate < stop && docDate > start)emit(meta.id,{'sensorReading':doc.sensorReading,'sensorType':doc.sensorType,'sensorname':doc.sensorname,'value':doc.value});}}"

